if (instance_exists(dialogue_obj)) exit;

if room == Room1 and !has_spoken
{
	if (keyboard_check_pressed(vk_down))
	{
		create_dialogue([
		{
			name: "Harry's Phone",
			msg: "RING RING."
		},
		
		{
			name: "Harry",
			msg: "Huh? Oh, my phone's ringing. (ANSWERS CALL.) Hello?"
		},

		{
			name: "Lyndon",
			msg: "Yo homie come chill at my place, we partyin'."
		},
		
		{
			name: "Harry",
			msg: "I've got my Data Structures and Algorithms exam tomorrow..."
		},
		
		{
			name: "CHOICE",
			msg: "Should Harry go to the library or go to the party?\n Up Arrow - Party\n Down Arrow - Library\nPress down key to remove dialogue box before making your choice."
		}
		])
		has_spoken = true;
	}
}

else if has_spoken and room == Room1 and !instance_exists(dialogue_obj)
{
	if(keyboard_check_pressed(vk_up))
			{
				has_spoken = false
				room_goto(Room5);
			}
			
			else if(keyboard_check_pressed(vk_down))
			{
				has_spoken = false
				room_goto(Room2);
			}		
}

if room == Room2 and !has_spoken
{
	sprite_index = player_idle_right_spr;
	if (keyboard_check_pressed(vk_down))
	{
		create_dialogue([
			{
				name: "Sherard",
				msg: "yo bro wassup"
			},
			{
				name: "CHOICE",
				msg: "Should Harry talk to Sherard or tell him to shut up?\n Up Arrow - Talk to Sherard\n Down Arrow - Tell Sherard to shut up\nPress down key to remove dialogue box before making your choice."
			}
			])
			has_spoken = true
	}
}
else if has_spoken and room == Room2 and !instance_exists(dialogue_obj)
{
	if(keyboard_check_pressed(vk_up))
			{
				has_spoken = false
				room_goto(Room3)
			}
			
			else if(keyboard_check_pressed(vk_down))
			{
				has_spoken = false
				room_goto(Room4);
			}		
}

if room == Room3 and !has_spoken
{
	sprite_index = player_idle_right_spr;
	create_dialogue([
				{
					name: "Harry",
					msg: "hey man, I'm good."
				},
				{
					name: "Librarian",
					msg: "If you guys are going to talk, please vacate the premises to do so."
				}
				])
				has_spoken = true
}
else if has_spoken and room == Room3 and !instance_exists(dialogue_obj)
{
	has_spoken = false
	room_goto(Room12);
}

if room == Room4 and !has_spoken
{
	create_dialogue([
	{
		name: "Harry",
		msg: "Shut up man, I'm trying to work."
	},
				
	{
		name: "Sherard",
		msg: "WHAT'S YOUR PROBLEM BRO, YOU WANNA FIGHT?!"
	},
				
	{
		name: "Librarian",
		msg: "Excuse me, that is quite enough. I must ask you to leave if you're going to cause such a ruckus."
	}
	])
	has_spoken = true
}
else if has_spoken and room == Room4 and !instance_exists(dialogue_obj)
{
	has_spoken = false
	room_goto(Room12);
}

if room == Room5 and !has_spoken
{
	sprite_index = player_back_party_spr;
	create_dialogue([
	{
		name: "Lyndon",
		msg: "YOOOO BRO YOU MADE IT!!"
	},
				
	{
		name: "Harry",
		msg: "Hey, mate."
	},
				
	{
		name: "Lyndon",
		msg: "Lily's here, so do you wanna talk to my pals or talk to her?"
	},
	
	{
		name: "CHOICE",	
		msg: "Should Harry talk to Lyndon's friends or talk to Lily?\n Up Arrow - Talk to Lyndon's friends\n Down Arrow - Talk to Lily\nPress down key to remove dialogue box before making your choice."
	}
	])
	has_spoken = true
}
else if has_spoken and room == Room5 and !instance_exists(dialogue_obj)
{
        if(keyboard_check(vk_up))
		{
            room_goto(Room9)
            has_spoken = false
        }
        else if(keyboard_check_pressed(vk_down))
		{
            room_goto(Room6)
            has_spoken = false
        }
}

else if(room == Room6 and !has_spoken)
{
	sprite_index = player_idle_right_party_spr;
    create_dialogue([
        {
            name: "Lily",
            msg: "Hi, Harry"
        },

        {
            name: "CHOICE",
            msg: "Should Harry say hi or ask her out?\n Up Arrow - Say hi\n Down Arrow - Ask her out\nPress down key to remove dialogue box before making your choice."
        }
    ])
    has_spoken = true;
}

else if(has_spoken and !instance_exists(dialogue_obj) and room == Room6)
{
        if(keyboard_check(vk_up)){
            has_spoken = false
            room_goto(Room7)
        }
        else if(keyboard_check_pressed(vk_down)){
            has_spoken = false
            room_goto(Room8)
        }
}

else if(room == Room7 and !has_spoken)
{
	sprite_index = player_idle_right_party_spr;
    create_dialogue([
        {
            name: "Harry",
            msg: "Hi Lily, would you say you are more of an algorithms or data structures person?"
        },

        {
            name: "Lily",
            msg: "I actually don't care about that."
        },

        {
            name: "Harry",
            msg: "Oh uhhh, okay... I'm just... gonna go home... bye..."
        }
    ])
    has_spoken = true;
}

else if(room == Room8 and !has_spoken)
{
	sprite_index = player_idle_right_party_spr;
    create_dialogue([
        {
            name: "Harry",
            msg: "Hi Lily, would you like to go out with me?"
        },

        {
            name: "Lily",
            msg: "Yes, I would love to!"
        },

        {
            name: "Harry",
            msg: "Great! I gotta go home now though, I'll see you soon!"
        }
    ])
    has_spoken = true;
}

else if( (room == Room7 || room == Room8) and has_spoken and !instance_exists(dialogue_obj) ){
    has_spoken = false
    room_goto(Room12)
}
else if(room == Room9 and !has_spoken){
    create_dialogue([
        {
            name: "Harry (INTERNALLY)",
            msg: "Damn, should I be nonchalant or chalant with these guys?"
        },

        {
            name: "CHOICE",
            msg: "Should Harry be nonchalant or chalant with his friends?\n Up Arrow - Be nonchalant\n Down Arrow - Be chalant\nPress down key to remove dialogue box before making your choice."
        }
    ])
	
    has_spoken = true;
}
else if(room == Room9 and has_spoken and !instance_exists(dialogue_obj)){
    if(keyboard_check(vk_up)){
        has_spoken = false
        room_goto(Room10)
    }

    else if(keyboard_check(vk_down)){
        has_spoken = false
        room_goto(Room11)
    }
}

else if(room == Room10 and !has_spoken){
    create_dialogue([
        {
            name: "Harry",
            msg: "Hey... I'm Harry"
        },

        {
            name: "Katie",
            msg: "Uhh yea we can see your name."
        },

        {
            name: "Harry",
            msg: "Why did I introduce myself like that, I should just go home"
        }
    ])
    has_spoken = true;
}

else if(room == Room11 and !has_spoken){
    create_dialogue([
        {
            name: "Harry",
            msg: "Hey guys, I'm Harry!"
        },

        {
            name: "Noah",
            msg: "Alright mate, I'm Noah, lovely to meet you."
        },
    ])
    has_spoken = true;
}

else if( (room == Room10 || room == Room11) and has_spoken and !instance_exists(dialogue_obj) ){
    has_spoken = false
    room_goto(Room12)
}

else if(room == Room12 and !has_spoken)
{
	create_dialogue([
        {
            name: "Narrator",
            msg: "After what happened, Harry went home."
        }
	])
	has_spoken = true
}

else if( (room == Room12) and has_spoken and !instance_exists(dialogue_obj) )
{
	has_spoken = false
	room_goto(exam_room);
}

else if room == rm_outside and !has_spoken
{
	sprite_index = player_idle_left_spr;
	if global.total_score == 3
			{
				create_dialogue([
					{ 
						name: "Chris", 
						msg: "Hello Harry! My name's Chris from JPMorgan. I've just reviewed your algorithm exam paper." 
					},
				
				    { 
						name: "Chris", 
						msg: "Congratulations! We'd love to invite you to join JPMorgan!" 
					},
				
				    { 
						name: "Harry", 
						msg: "Thank you Chris! I'm thrilled to join!" 
					}
				    ]);
					has_spoken = true;
			
			} else {
					create_dialogue([
						{ 
							name: "Chris",
							msg: "Hello Harry. It's Chris from JPMorgan. I've had a look at your algorithm exam paper." 
						},
						
				        { 
							name: "Chris", 
							msg: "Unfortunately, you failed, meaning we cannot hire you" 
						},
						
				        { 
							name: "Harry", 
							msg: "Its my own fault.. I will do better next time!" 
						}
				        ]);
						has_spoken = true;
			}
}
else if( (room == rm_outside) and has_spoken and !instance_exists(dialogue_obj) )
{
	room_goto(finalroom)	
}