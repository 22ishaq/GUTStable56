has_spoken = false;
global.taking_exam = false;