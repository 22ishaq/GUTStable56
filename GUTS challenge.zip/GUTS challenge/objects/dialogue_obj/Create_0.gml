messages = [];
current_message = -1;
current_char = 0;
draw_message = "";

char_speed = 2;
input_key = vk_down;

gui_w = display_get_gui_width();
gui_h = display_get_gui_height();

is_talking = true;



