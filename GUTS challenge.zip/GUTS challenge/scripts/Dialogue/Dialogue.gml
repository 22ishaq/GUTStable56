function create_dialogue(_messages){
	if (instance_exists(dialogue_obj)) return;
	
	var _inst = instance_create_depth(0, 0, 0, dialogue_obj);
	_inst.messages = _messages;
	_inst.current_message = 0;
	
}