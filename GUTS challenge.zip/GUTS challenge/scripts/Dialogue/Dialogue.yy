{
  "$GMScript":"v1",
  "%Name":"Dialogue",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Dialogue",
  "parent":{
    "name":"GUTS challenge",
    "path":"GUTS challenge.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}